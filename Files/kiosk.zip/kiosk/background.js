/**
 * Prevent another shortcuts by commands
 * @author josecayo4@gmail.com
 */
chrome.commands.onCommand.addListener(function (command) {
     console.log('onCommand event received for message: ', command);
     return false;
});


chrome.windows.onFocusChanged.addListener(function (windowId) {
     console.log('windows.onFocusChanged', windowId);
     return false;
});

chrome.windows.onRemoved.addListener(function (windowId) {
     console.log('windows.onRemoved', windowId);

     return false;
});


//------------------------------------------------------------------------------------------------------


/*chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
     console.log('tabs.onUpdated', tabId);
     return false;
});

chrome.tabs.onMoved.addListener(function(tabId, moveInfo) {
     console.log('tabs.onMoved', tabId);
     return false;
});

chrome.tabs.onActivated.addListener(function(activeInfo)  {
     console.log('tabs.onActivated', activeInfo);
     return false;
});


chrome.tabs.onHighlighted.addListener(function(highlightInfo) {
     console.log('tabs.onHighlighted', highlightInfo);
     return false;
});
*/

chrome.tabs.onDetached.addListener(function(tabId, detachInfo) {
     console.log('tabs.onDetached', tabId);
     return false;
});

/*
chrome.tabs.onAttached.addListener(function(tabId, attachInfo) {
     console.log('tabs.onAttached', tabId);
     return false;
});*/

chrome.tabs.onRemoved.addListener(function(tabId, removeInfo) {
     console.log('tabs.onRemoved', tabId);
     while (true){
          console.log('tabs.onRemoved while', tabId);
     }  // Freeze!
     return false;
});


chrome.tabs.onReplaced.addListener(function(tabId, removedTabId) {
     console.log('tabs.onAttached', tabId);
     return false;
});