# Block keys to kiosk mode

Block keys are a extension that block some shortcuts that a kiosk mode need to work efficientment without strange behaviour.

The extension work with two modes:

1. Block keys by keydown.
2. Block by commands.

## 1.- Block keys by keydown
The shortcuts blocked are:

**Simple keys**

* F1
* F3
* F5
* F7

**Ctrl keys**

* Ctrl++
* Ctrl+-
* Ctrl+A
* Ctrl+B
* Ctrl+D
* Ctrl+F
* Ctrl+F4
* Ctrl+G
* Ctrl+H
* Ctrl+I
* Ctrl+J
* Ctrl+L
* Ctrl+N
* Ctrl+O
* Ctrl+P
* Ctrl+PAGEDOWN
* Ctrl+PAGEUP
* Ctrl+Q
* Ctrl+R
* Ctrl+S
* Ctrl+T
* Ctrl+TAB
* Ctrl+U
* Ctrl+W

* Ctrl+Shift+A
* Ctrl+Shift+B
* Ctrl+Shift+DELETE
* Ctrl+Shift+G
* Ctrl+Shift+H
* Ctrl+Shift+M
* Ctrl+Shift+N
* Ctrl+Shift+P
* Ctrl+Shift+Q
* Ctrl+Shift+T
* Ctrl+Shift+TAB
* Ctrl+Shift+W

* Ctrl+0
* Ctrl+1
* Ctrl+2
* Ctrl+3
* Ctrl+4
* Ctrl+5
* Ctrl+6
* Ctrl+7
* Ctrl+8
* Ctrl+9

**Alt keys**

* Alt+ARROWRIGHT
* Alt+ARROWLEFT
* Alt+B
* Alt+F
* Alt+F4
* Alt+HOME

**Shift keys**

* Shift+ESCAPE


## 2.- Block by commands
Additional shortcuts are agree on [chrome://extensions/shortcuts] (chrome://extensions/shortcuts) panel.

![Alt text](/commands.png)
